# Requirements
This project requires
- Docker 18.06.1-ce
- Docker Compose  1.22.0
- Docker Machine 0.15.0 (Optional) 
- PC, Mac or Linux
- Git 2.15.1