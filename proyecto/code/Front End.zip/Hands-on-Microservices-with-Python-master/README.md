# Packt Hands on Microservices with Python

Author: Peter Fisher

# Installation
- Read the [requirements](docs/install/requirements.md) guide first
- To install the whole application read the [Microservices installation guide](docs/install/microservices.md)
- To install just the frontend read the [Frontend installation guide](docs/install/frontend.md)